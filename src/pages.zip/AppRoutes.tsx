// src/AppRoutes.tsx
import { Routes, Route, Navigate } from "react-router-dom";
import Auth from "./pages/auth/Auth";
import Navigation from "./pages/navigation/Navigation";
import Home from "./pages/home/Home";

interface Props {
  toggleTheme: () => void;
}

export function AppRoutes({ toggleTheme }: Props) {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/auth" replace />} />

      <Route path="/auth/*" element={<Auth />} />

      <Route path="/app/*" element={<Navigation toggleTheme={toggleTheme} />}>
        <Route index element={<Navigate to="home" replace />} />
        <Route path="home" element={<Home />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
