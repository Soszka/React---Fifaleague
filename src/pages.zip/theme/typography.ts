export const typography = {
  button: { textTransform: "none" }, // usuwa UPPERCASE
};
