import React from "react";
import { Box, Typography, Paper, useTheme } from "@mui/material";
import SportsScoreIcon from "@mui/icons-material/SportsScore";
import EventNoteIcon from "@mui/icons-material/EventNote";
import EmojiEventsIcon from "@mui/icons-material/EmojiEvents";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import styles from "./home-stats.module.scss";

interface HighlightItemProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  gradient: string;
  ariaLabel?: string;
}

const HighlightItem: React.FC<HighlightItemProps> = ({
  icon,
  label,
  value,
  gradient,
  ariaLabel,
}) => (
  <Paper
    className={styles.highlightCard}
    elevation={12}
    sx={{ background: gradient, borderRadius: "32px", overflow: "hidden" }}
    aria-label={ariaLabel || label}
  >
    <Box className={styles.textContainer}>
      <Typography variant="h3" component="p" className={styles.valueText}>
        {value}
      </Typography>
      <Typography
        variant="subtitle1"
        component="p"
        className={styles.labelText}
      >
        {label}
      </Typography>
    </Box>
    <Box className={styles.iconContainer}>{icon}</Box>
  </Paper>
);

const HomeStats: React.FC = () => {
  const theme = useTheme();

  const lightGradients = [
    "linear-gradient(135deg,#ffffff 0%,#8e8e8e 100%)",
    "linear-gradient(135deg,#f4f4f4 0%,#7a7a7a 100%)",
    "linear-gradient(135deg,#e9e9e9 0%,#6b6b6b 100%)",
    "linear-gradient(135deg,#fafafa 0%,#909090 100%)",
  ];
  const darkGradients = [
    "linear-gradient(135deg,#757575 0%,#000000 100%)",
    "linear-gradient(135deg,#666666 0%,#000000 100%)",
    "linear-gradient(135deg,#858585 0%,#000000 100%)",
    "linear-gradient(135deg,#707070 0%,#000000 100%)",
  ];

  const gradients =
    theme.palette.mode === "dark" ? darkGradients : lightGradients;
  const iconColor = theme.palette.mode === "dark" ? "#ffffff" : "#000000";

  const highlightData: HighlightItemProps[] = [
    {
      icon: <SportsScoreIcon sx={{ fontSize: 100, color: iconColor }} />,
      label: "Wynik ostatniego rozegranego meczu",
      value: "3 : 1",
      gradient: gradients[0],
    },
    {
      icon: <EventNoteIcon sx={{ fontSize: 100, color: iconColor }} />,
      label: "Mecze rozegrane w tym tygodniu",
      value: "7",
      gradient: gradients[1],
    },
    {
      icon: <EmojiEventsIcon sx={{ fontSize: 100, color: iconColor }} />,
      label: "Procent wygranych spotkań",
      value: "72 %",
      gradient: gradients[2],
    },
    {
      icon: <TrendingUpIcon sx={{ fontSize: 100, color: iconColor }} />,
      label: "Średnia zdobnytych goli na mecz",
      value: "2,3",
      gradient: gradients[3],
    },
  ];

  return (
    <Box className={styles.highlightsContainer} sx={{ mt: 6 }}>
      {highlightData.map((item, idx) => (
        <HighlightItem key={idx} {...item} />
      ))}
    </Box>
  );
};

export default HomeStats;
