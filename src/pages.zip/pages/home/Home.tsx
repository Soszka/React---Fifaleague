// src/pages/Home/Home.tsx
import React from "react";
import { useTranslation } from "react-i18next";
import { Box, Typography } from "@mui/material";

import HomeScoreboard from "./home-scoreboard/HomeScoreboard";
import HomeCard from "./home-card/HomeCard";
import HomeStats from "./home-stats/HomeStats";
import { Title } from "../../common/UI/Title";

import styles from "./home.module.scss";

// importy obrazków z Twojego src/assets
import aboutImg from "../../assets/cardsPhoto5.png";
import matchesImg from "../../assets/cardsPhoto1.png";
import statsImg from "../../assets/cardsPhoto3.png";
import tableImg from "../../assets/cardsPhoto4.png";
import teamsImg from "../../assets/cardsPhoto2.png";
import rankingImg from "../../assets/auth_photo.jpg";

interface CardItem {
  header: string;
  content: string;
  image: string;
  link: string;
}

const cardsConfig = (t: ReturnType<typeof useTranslation>["t"]): CardItem[] => [
  {
    header: t("home.card.about.title"),
    content: t("home.card.about.description"),
    image: aboutImg,
    link: "/navigation/about",
  },
  {
    header: t("home.card.matches.title"),
    content: t("home.card.matches.description"),
    image: matchesImg,
    link: "/navigation/matches",
  },
  {
    header: t("home.card.stats.title"),
    content: t("home.card.stats.description"),
    image: statsImg,
    link: "/navigation/stats",
  },
  {
    header: t("home.card.table.title"),
    content: t("home.card.table.description"),
    image: tableImg,
    link: "/navigation/table",
  },
  {
    header: t("home.card.teams.title"),
    content: t("home.card.teams.description"),
    image: teamsImg,
    link: "/navigation/teams",
  },
  {
    header: t("home.card.ranking.title"),
    content: t("home.card.ranking.description"),
    image: rankingImg,
    link: "/navigation/ranking",
  },
];

const Home: React.FC = () => {
  const { t } = useTranslation();
  const cards = React.useMemo(() => cardsConfig(t), [t]);

  return (
    <Box className={styles.container} sx={{ width: "100%" }}>
      <HomeScoreboard />

      <Typography variant="h3" sx={{ ml: 3, mt: 4, fontWeight: 700 }}>
        Witaj Bartek
      </Typography>

      <Typography variant="h6" sx={{ ml: 3, mt: 1, maxWidth: 1200 }}>
        Zapraszamy do kolejnej dawki pasjonujących meczów, statystyk i
        piłkarskich emocji, które już czekają na Twoje odkrycie!
      </Typography>
      <HomeStats />

      {/* opcjonalny nagłówek sekcji kart */}
      <Box sx={{ mt: 6, mb: 1, px: 3, maxWidth: 1800, mx: "auto" }}>
        <Title subtitle={t("home.subtitle")} title={t("home.title")} />
      </Box>

      <div className={styles.cards}>
        {cards.map((card) => (
          <HomeCard
            key={card.link}
            header={card.header}
            content={card.content}
            image={card.image}
            link={card.link}
          />
        ))}
      </div>
    </Box>
  );
};

export default Home;
