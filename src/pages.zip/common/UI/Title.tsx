// ────────────────────────────────────────────────────────────
// Title.tsx – full‑width accent bar with grow animation (theme‑aware)
// ────────────────────────────────────────────────────────────
import React from "react";
import { Box, Typography, useTheme, keyframes } from "@mui/material";

export interface TitleProps {
  title: string;
  subtitle: string;
}

// underline grows smoothly from the left edge
const grow = keyframes`
  from { transform: scaleX(0); opacity: 0; }
  to   { transform: scaleX(1); opacity: 1; }
`;

export const Title: React.FC<TitleProps> = ({ title, subtitle }) => {
  const theme = useTheme();
  const accent =
    theme.palette.mode === "dark"
      ? theme.palette.primary.light
      : theme.palette.primary.main;

  return (
    <Box sx={{ width: "100%", mb: { xs: 3, md: 3 } }}>
      {/* subtitle */}
      <Typography
        variant="subtitle1"
        color="text.secondary"
        sx={{ fontWeight: 600, letterSpacing: 0.5, mb: 0.5 }}
      >
        {subtitle}
      </Typography>

      {/* title & animated full‑width bar */}
      <Box sx={{ display: "flex", alignItems: "flex-end" }}>
        <Typography
          variant="h4"
          sx={{
            textTransform: "uppercase",
            fontWeight: 700,
            lineHeight: 1,
            color: "text.primary",
            mr: 2,
          }}
        >
          {title}
        </Typography>
        <Box
          sx={{
            flexGrow: 1,
            height: 4,
            mb: 0.5,
            bgcolor: accent,
            borderRadius: 2,
            transformOrigin: "left",
            animation: `${grow} 1.2s cubic-bezier(0.25, 1, 0.5, 1) forwards`,
          }}
        />
      </Box>
    </Box>
  );
};

export default Title;
